// Testes da documentação OpenAPI e dos contratos de validação (400 x 422)
const path = require('path');
const fs = require('fs');
const os = require('os');

const dbTemp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'livraria-docs-')), 'database.test.txt');
process.env.DB_PATH = dbTemp;
process.env.JWT_SECRET = process.env.JWT_SECRET || 'segredo-de-teste-com-mais-de-trinta-e-dois-caracteres';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const SwaggerParser = require('@apidevtools/swagger-parser');
const app = require('../server');

let server, raiz;
const api = async (metodo, rota, { corpo, token, bruto } = {}) => {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const body = bruto !== undefined ? bruto : (corpo ? JSON.stringify(corpo) : undefined);
  const res = await fetch(raiz + '/api/v1' + rota, { method: metodo, headers, body });
  return { status: res.status, dados: await res.json() };
};
const login = async (email, senha) => (await api('POST', '/auth/login', { corpo: { email, senha } })).dados.token;

before(async () => {
  server = app.listen(0);
  await new Promise(r => server.once('listening', r));
  raiz = `http://127.0.0.1:${server.address().port}`;
});
after(() => { server.close(); fs.rmSync(path.dirname(dbTemp), { recursive: true, force: true }); });

test('Swagger UI é servido em /api/docs e /docs redireciona para ele', async () => {
  const ui = await fetch(raiz + '/api/docs/');
  assert.equal(ui.status, 200);
  assert.match(await ui.text(), /swagger-ui/i);
  const redir = await fetch(raiz + '/docs', { redirect: 'manual' });
  assert.equal(redir.status, 301);
  assert.equal(redir.headers.get('location'), '/api/docs');
});

test('Especificação JSON é OpenAPI 3.0 válida, com Bearer JWT e todas as rotas', async () => {
  for (const rota of ['/api/docs.json', '/api-docs.json']) {
    const res = await fetch(raiz + rota);
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /application\/json/);
  }
  const spec = await (await fetch(raiz + '/api/docs.json')).json();
  assert.match(spec.openapi, /^3\.0\./);
  await SwaggerParser.validate(structuredClone(spec));

  assert.deepEqual(spec.components.securitySchemes.bearerAuth, {
    ...spec.components.securitySchemes.bearerAuth, type: 'http', scheme: 'bearer', bearerFormat: 'JWT'
  });

  // Matriz exigida: rota -> status codes que precisam estar documentados
  const matriz = {
    'get /livros': ['200', '500'],
    'get /livros/{id}': ['200', '404'],
    'post /auth/register': ['201', '400', '422', '409'],
    'post /auth/login': ['200', '400', '422', '401'],
    'post /livros/{id}/comentarios': ['201', '400', '422', '401', '404'],
    'post /autores': ['201', '400', '422', '401', '403'],
    'post /livros': ['201', '400', '422', '401', '403']
  };
  for (const [chave, codigos] of Object.entries(matriz)) {
    const [metodo, rota] = chave.split(' ');
    const op = spec.paths[rota] && spec.paths[rota][metodo];
    assert.ok(op, `rota não documentada: ${chave}`);
    assert.ok(op.summary && op.description, `${chave} sem summary/description`);
    for (const c of codigos) assert.ok(op.responses[c], `${chave} sem resposta ${c}`);
    const protegida = codigos.includes('401') && metodo === 'post' && !rota.startsWith('/auth');
    assert.equal(Boolean(op.security && op.security.some(s => s.bearerAuth)), protegida, `${chave}: security incorreta`);
  }
});

test('Validação: 400 para campo ausente/JSON malformado e 422 para formato inválido', async () => {
  const r400 = await api('POST', '/auth/register', { corpo: { nome: 'Ana', email: 'ana@x.com' } });
  assert.equal(r400.status, 400);
  assert.deepEqual(r400.dados.detalhes, [{ campo: 'senha', mensagem: 'Campo obrigatório.' }]);

  assert.equal((await api('POST', '/auth/login', { bruto: '{"email": ' })).status, 400);

  const r422 = await api('POST', '/auth/register', { corpo: { nome: 'Ana', email: 'nao-e-email', senha: '123' } });
  assert.equal(r422.status, 422);
  assert.deepEqual(r422.dados.detalhes.map(d => d.campo), ['email', 'senha']);

  assert.equal((await api('POST', '/auth/login', { corpo: { email: 'a@b.com', senha: 123456 } })).status, 422);

  const admin = await login('admin@livraria.com', 'admin123');
  assert.equal((await api('POST', '/autores', { corpo: { nome: '   ' }, token: admin })).status, 400);
  assert.equal((await api('POST', '/livros', { corpo: { titulo: 'X' }, token: admin })).status, 400);
  assert.equal((await api('POST', '/livros', { corpo: { titulo: 'X', autor_id: 1, ano: 'mil' }, token: admin })).status, 422);
  const semAutor = await api('POST', '/livros', { corpo: { titulo: 'X', autor_id: 999 }, token: admin });
  assert.equal(semAutor.status, 422);
  assert.equal(semAutor.dados.detalhes[0].campo, 'autor_id');

  const leitor = await login('leitor@gmail.com', 'leitor123');
  assert.equal((await api('POST', '/livros/1/comentarios', { corpo: { texto: '' }, token: leitor })).status, 400);
  assert.equal((await api('POST', '/livros/1/comentarios', { corpo: { texto: 'a'.repeat(1001) }, token: leitor })).status, 422);
  assert.equal((await api('POST', '/livros/999/comentarios', { corpo: { texto: 'Oi' }, token: leitor })).status, 404);
  assert.equal((await api('GET', '/livros/999')).status, 404);
});
