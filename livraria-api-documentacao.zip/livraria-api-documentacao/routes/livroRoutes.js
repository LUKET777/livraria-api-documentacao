const { Router } = require('express');
const controller = require('../controllers/LivroController');
const { autenticarToken, exigirRole } = require('../middlewares/authMiddleware');

const router = Router();

/**
 * @openapi
 * /livros:
 *   get:
 *     tags: [Livros]
 *     summary: Lista todos os livros
 *     description: Rota **pública**. Retorna o acervo completo, com o nome do autor e os comentários de cada livro.
 *     responses:
 *       200:
 *         description: Lista de livros (pode ser vazia).
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/LivroDetalhado'
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 *   post:
 *     tags: [Livros]
 *     summary: Cadastra um novo livro (ADMIN)
 *     description: |
 *       Rota **exclusiva do perfil ADMIN** (exige `Authorization: Bearer <token>`).
 *
 *       Regras:
 *       - `titulo` e `autor_id` são obrigatórios;
 *       - `autor_id` deve referenciar um autor existente (cadastre-o antes em `POST /autores`);
 *       - `ano` é opcional, inteiro e não pode ser futuro (padrão: ano atual).
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LivroInput'
 *     responses:
 *       201:
 *         description: Livro criado (sem comentários).
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Livro'
 *       400:
 *         description: Corpo ausente, JSON malformado ou `titulo`/`autor_id` faltando.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Campos obrigatórios ausentes: autor_id.'
 *               detalhes: [{ campo: 'autor_id', mensagem: 'Campo obrigatório.' }]
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/ForbiddenAdmin'
 *       422:
 *         description: Tipo/valor inválido ou `autor_id` de um autor inexistente.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             examples:
 *               anoInvalido:
 *                 summary: Ano não inteiro ou futuro
 *                 value:
 *                   erro: 'Dados inválidos.'
 *                   detalhes: [{ campo: 'ano', mensagem: 'Deve ser um número inteiro entre 1 e o ano atual.' }]
 *               autorInexistente:
 *                 summary: Autor não cadastrado
 *                 value:
 *                   erro: 'Dados inválidos.'
 *                   detalhes: [{ campo: 'autor_id', mensagem: 'O autor informado não existe.' }]
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.get('/', (req, res, next) => controller.index(req, res, next));
router.post('/', autenticarToken, exigirRole('ADMIN'), (req, res, next) => controller.store(req, res, next));

/**
 * @openapi
 * /livros/{id}:
 *   get:
 *     tags: [Livros]
 *     summary: Busca um livro pelo ID
 *     description: Rota **pública**. Retorna um livro com o nome do autor e seus comentários.
 *     parameters:
 *       - $ref: '#/components/parameters/LivroId'
 *     responses:
 *       200:
 *         description: Livro encontrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LivroDetalhado'
 *       404:
 *         $ref: '#/components/responses/LivroNaoEncontrado'
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.get('/:id', (req, res, next) => controller.show(req, res, next));

/**
 * @openapi
 * /livros/{id}/comentarios:
 *   post:
 *     tags: [Comentários]
 *     summary: Adiciona um comentário a um livro (USER ou ADMIN)
 *     description: |
 *       Rota para **qualquer usuário autenticado** (perfil `USER` ou `ADMIN`).
 *
 *       O autor do comentário é extraído do token JWT validado (claims `sub` e `nome`); campos de autoria enviados no corpo são ignorados.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - $ref: '#/components/parameters/LivroId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ComentarioInput'
 *     responses:
 *       201:
 *         description: Comentário criado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Comentario'
 *             example:
 *               id: 1760917200000
 *               usuario_id: '2'
 *               autor_nome: 'Leitor'
 *               autor_comentario: 'Leitor'
 *               texto: 'Narrativa intensa, recomendo a leitura!'
 *       400:
 *         description: Corpo ausente, JSON malformado ou `texto` vazio.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'O texto do comentário não pode estar vazio.'
 *               detalhes: [{ campo: 'texto', mensagem: 'Campo obrigatório.' }]
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/LivroNaoEncontrado'
 *       422:
 *         description: '`texto` com tipo inválido ou acima de 1000 caracteres.'
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Dados inválidos.'
 *               detalhes: [{ campo: 'texto', mensagem: 'Deve ter no máximo 1000 caracteres.' }]
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.post('/:id/comentarios', autenticarToken, (req, res, next) => controller.storeComment(req, res, next));

module.exports = router;
