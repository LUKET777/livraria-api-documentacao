const { Router } = require('express');
const controller = require('../controllers/AuthController');

const router = Router();

/**
 * @openapi
 * /auth/register:
 *   post:
 *     tags: [Autenticação]
 *     summary: Cadastra um novo usuário leitor
 *     description: |
 *       Rota **pública**. Cria um usuário com perfil `USER` e grava a senha como hash **BCrypt** (a senha nunca é armazenada nem retornada em texto puro).
 *
 *       Regras:
 *       - `nome`, `email` e `senha` são obrigatórios;
 *       - o e-mail é normalizado (minúsculas, sem espaços) e deve ser único;
 *       - a senha precisa ter entre 6 e 72 caracteres;
 *       - qualquer `role` enviada no corpo é ignorada (impede escalonamento de privilégio).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegistroInput'
 *     responses:
 *       201:
 *         description: Usuário criado. O hash da senha não é retornado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Usuario'
 *       400:
 *         description: Corpo ausente, JSON malformado ou campo obrigatório faltando.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Campos obrigatórios ausentes: senha.'
 *               detalhes: [{ campo: 'senha', mensagem: 'Campo obrigatório.' }]
 *       409:
 *         description: Já existe um usuário com este e-mail.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example:
 *               erro: 'E-mail já cadastrado no sistema.'
 *       422:
 *         description: Campos presentes, mas com formato inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Dados inválidos.'
 *               detalhes:
 *                 - { campo: 'email', mensagem: 'Deve ser um e-mail válido.' }
 *                 - { campo: 'senha', mensagem: 'Deve ter entre 6 e 72 caracteres.' }
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.post('/register', (req, res, next) => controller.register(req, res, next));

/**
 * @openapi
 * /auth/login:
 *   post:
 *     tags: [Autenticação]
 *     summary: Autentica o usuário e emite um token JWT
 *     description: |
 *       Rota **pública**. Valida as credenciais com `bcrypt.compare` e retorna um **JWT HS256** (validade padrão de 1h) com as claims `sub` (id), `nome` e `role`.
 *
 *       Use o `token` retornado no botão **Authorize** (nesta documentação ele é aplicado automaticamente após um login bem-sucedido).
 *
 *       Por segurança, a mensagem de falha é genérica e não informa se o erro está no e-mail ou na senha.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginInput'
 *           examples:
 *             admin:
 *               summary: ADMIN
 *               value: { email: 'admin@livraria.com', senha: 'admin123' }
 *             leitor:
 *               summary: USER (Leitor)
 *               value: { email: 'leitor@gmail.com', senha: 'leitor123' }
 *     responses:
 *       200:
 *         description: Login realizado. Retorna os dados públicos do usuário e o token.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LoginResposta'
 *       400:
 *         description: Corpo ausente, JSON malformado, e-mail ou senha não informados.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'E-mail e senha são obrigatórios.'
 *               detalhes: [{ campo: 'senha', mensagem: 'Campo obrigatório.' }]
 *       401:
 *         description: Credenciais inválidas (e-mail inexistente ou senha incorreta).
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example:
 *               erro: 'Credenciais inválidas.'
 *       422:
 *         description: 'E-mail ou senha enviados com tipo inválido (ex.: número em vez de texto).'
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Dados inválidos.'
 *               detalhes: [{ campo: 'senha', mensagem: 'Deve ser um texto.' }]
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.post('/login', (req, res, next) => controller.login(req, res, next));

module.exports = router;
