const { Router } = require('express');
const controller = require('../controllers/AutorController');
const { autenticarToken, exigirRole } = require('../middlewares/authMiddleware');

const router = Router();

/**
 * @openapi
 * /autores:
 *   get:
 *     tags: [Autores]
 *     summary: Lista todos os autores
 *     description: Rota **pública**. Útil para descobrir o `autor_id` usado no cadastro de livros.
 *     responses:
 *       200:
 *         description: Lista de autores (pode ser vazia).
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Autor'
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 *   post:
 *     tags: [Autores]
 *     summary: Cadastra um novo autor (ADMIN)
 *     description: |
 *       Rota **exclusiva do perfil ADMIN** (exige `Authorization: Bearer <token>`).
 *
 *       `nome` é obrigatório; `nacionalidade` é opcional (padrão: "Não informada").
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AutorInput'
 *     responses:
 *       201:
 *         description: Autor criado. Use o `id` retornado como `autor_id` em `POST /livros`.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Autor'
 *             example:
 *               id: 1760917200000
 *               nome: 'Clarice Lispector'
 *               nacionalidade: 'Brasileira'
 *       400:
 *         description: Corpo ausente, JSON malformado ou `nome` vazio.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'O nome do autor é obrigatório.'
 *               detalhes: [{ campo: 'nome', mensagem: 'Campo obrigatório.' }]
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/ForbiddenAdmin'
 *       422:
 *         description: Campos com tipo ou tamanho inválido.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErroValidacao'
 *             example:
 *               erro: 'Dados inválidos.'
 *               detalhes: [{ campo: 'nome', mensagem: 'Deve ter entre 2 e 120 caracteres.' }]
 *       500:
 *         $ref: '#/components/responses/ErroInterno'
 */
router.get('/', (req, res, next) => controller.index(req, res, next));
router.post('/', autenticarToken, exigirRole('ADMIN'), (req, res, next) => controller.store(req, res, next));

module.exports = router;
