const path = require('path');
const swaggerJsdoc = require('swagger-jsdoc');
const { version } = require('../package.json');

/**
 * Definição base da OpenAPI Specification 3.0.
 * Os paths são lidos das anotações @openapi nos arquivos de rotas (routes/*.js);
 * aqui ficam as informações gerais, o esquema de segurança e os schemas reutilizáveis.
 */
const definition = {
  openapi: '3.0.3',
  info: {
    title: 'Livraria API',
    version,
    description: [
      'API RESTful de **Livros e Autores** com autenticação stateless (JWT), senhas com hash BCrypt e controle de acesso por perfil (RBAC).',
      '',
      '### Como testar as rotas protegidas',
      '1. Abra **Autenticação → POST /auth/login**, clique em *Try it out* e execute com uma das credenciais abaixo.',
      '2. O token retornado é aplicado **automaticamente** no botão **Authorize** 🔓 (se preferir, copie o campo `token` e cole manualmente em *Authorize → bearerAuth*, sem o prefixo `Bearer`).',
      '3. Execute as rotas com cadeado (comentários, autores e livros). Para trocar de perfil, faça login novamente com o outro usuário ou use *Authorize → Logout*.',
      '',
      '| Perfil | E-mail | Senha |',
      '|---|---|---|',
      '| ADMIN | `admin@livraria.com` | `admin123` |',
      '| USER (Leitor) | `leitor@gmail.com` | `leitor123` |',
      '',
      '### Matriz de permissões',
      '| Método | Rota | Acesso |',
      '|---|---|---|',
      '| GET | `/livros`, `/livros/{id}`, `/autores` | Público |',
      '| POST | `/auth/register`, `/auth/login` | Público |',
      '| POST | `/livros/{id}/comentarios` | Autenticado (USER ou ADMIN) |',
      '| POST | `/autores`, `/livros` | Exclusivo ADMIN |',
      '',
      '### Convenção de erros',
      '- **400** — corpo ausente, JSON malformado ou campo obrigatório faltando.',
      '- **422** — campos presentes, porém com tipo, formato ou valor inválido (ex.: e-mail inválido, `ano` não inteiro, `autor_id` inexistente).',
      '- **401** — token ausente, sem o prefixo `Bearer`, com assinatura inválida/adulterado ou expirado.',
      '- **403** — usuário autenticado, mas sem o perfil exigido (ex.: USER em rota de ADMIN).',
      '',
      'Especificação bruta (JSON): [`/api/docs.json`](/api/docs.json)'
    ].join('\n'),
    contact: { name: 'Lucas Figueredo (Matrícula 2410469)' },
    license: { name: 'ISC' }
  },
  servers: [{ url: '/api/v1', description: 'Servidor atual (versão 1 da API)' }],
  tags: [
    { name: 'Autenticação', description: 'Cadastro de usuários e emissão de tokens JWT' },
    { name: 'Livros', description: 'Consulta pública e cadastro (ADMIN) de livros' },
    { name: 'Comentários', description: 'Comentários de usuários autenticados nos livros' },
    { name: 'Autores', description: 'Consulta pública e cadastro (ADMIN) de autores' }
  ],
  components: {
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Token JWT (HS256, validade padrão de 1h) obtido em `POST /auth/login`. Informe apenas o token; o prefixo `Bearer` é adicionado automaticamente.'
      }
    },
    parameters: {
      LivroId: {
        name: 'id',
        in: 'path',
        required: true,
        description: 'Identificador numérico do livro',
        schema: { type: 'integer', format: 'int64', minimum: 1 },
        example: 1
      }
    },
    schemas: {
      // ---------- Entradas ----------
      RegistroInput: {
        type: 'object',
        required: ['nome', 'email', 'senha'],
        additionalProperties: false,
        properties: {
          nome: { type: 'string', minLength: 2, maxLength: 100, example: 'Ana Beatriz Souza' },
          email: { type: 'string', format: 'email', maxLength: 254, example: 'ana.souza@email.com' },
          senha: { type: 'string', format: 'password', minLength: 6, maxLength: 72, example: 'leitura2026' }
        },
        description: 'O perfil é sempre `USER`; um campo `role` enviado no corpo é ignorado.'
      },
      LoginInput: {
        type: 'object',
        required: ['email', 'senha'],
        properties: {
          email: { type: 'string', format: 'email', example: 'admin@livraria.com' },
          senha: { type: 'string', format: 'password', example: 'admin123' }
        }
      },
      AutorInput: {
        type: 'object',
        required: ['nome'],
        properties: {
          nome: { type: 'string', minLength: 2, maxLength: 120, example: 'Clarice Lispector' },
          nacionalidade: { type: 'string', maxLength: 60, example: 'Brasileira', description: 'Opcional. Padrão: "Não informada".' }
        }
      },
      LivroInput: {
        type: 'object',
        required: ['titulo', 'autor_id'],
        properties: {
          titulo: { type: 'string', minLength: 1, maxLength: 200, example: 'A Hora da Estrela' },
          ano: { type: 'integer', minimum: 1, maximum: 2100, example: 1977, description: 'Opcional. Padrão: ano atual. Não pode ser futuro.' },
          autor_id: { type: 'integer', format: 'int64', minimum: 1, example: 1, description: 'ID de um autor já cadastrado' }
        }
      },
      ComentarioInput: {
        type: 'object',
        required: ['texto'],
        properties: {
          texto: { type: 'string', minLength: 1, maxLength: 1000, example: 'Narrativa intensa, recomendo a leitura!' }
        },
        description: 'O autor do comentário é obtido do token JWT, nunca do corpo da requisição.'
      },

      // ---------- Saídas ----------
      Usuario: {
        type: 'object',
        required: ['id', 'nome', 'email', 'role'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1760917200000 },
          nome: { type: 'string', example: 'Ana Beatriz Souza' },
          email: { type: 'string', format: 'email', example: 'ana.souza@email.com' },
          role: { type: 'string', enum: ['USER', 'ADMIN'], example: 'USER' }
        }
      },
      LoginResposta: {
        type: 'object',
        required: ['usuario', 'token'],
        properties: {
          usuario: {
            type: 'object',
            properties: {
              id: { type: 'integer', format: 'int64', example: 1 },
              nome: { type: 'string', example: 'Admin' },
              role: { type: 'string', enum: ['USER', 'ADMIN'], example: 'ADMIN' }
            }
          },
          token: {
            type: 'string',
            description: 'JWT a ser enviado em `Authorization: Bearer <token>`',
            example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub21lIjoiQWRtaW4iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE3NjA5MTcyMDAsImV4cCI6MTc2MDkyMDgwMCwic3ViIjoiMSJ9.assinatura'
          }
        }
      },
      Autor: {
        type: 'object',
        required: ['id', 'nome', 'nacionalidade'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1 },
          nome: { type: 'string', example: 'Machado de Assis' },
          nacionalidade: { type: 'string', example: 'Brasileiro' }
        }
      },
      Comentario: {
        type: 'object',
        required: ['id', 'autor_nome', 'texto'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1760917200000 },
          usuario_id: { type: 'string', description: 'ID do usuário que comentou (claim `sub` do JWT)', example: '2' },
          autor_nome: { type: 'string', example: 'Leitor' },
          autor_comentario: { type: 'string', description: 'Mesmo valor de `autor_nome` (campo usado pelo front-end)', example: 'Leitor' },
          texto: { type: 'string', example: 'Clássico indispensável.' }
        }
      },
      Livro: {
        type: 'object',
        required: ['id', 'titulo', 'ano', 'autor_id', 'comentarios'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1760917200000 },
          titulo: { type: 'string', example: 'A Hora da Estrela' },
          ano: { type: 'integer', example: 1977 },
          autor_id: { type: 'integer', format: 'int64', example: 1 },
          comentarios: { type: 'array', items: { $ref: '#/components/schemas/Comentario' }, example: [] }
        }
      },
      LivroDetalhado: {
        allOf: [
          { $ref: '#/components/schemas/Livro' },
          {
            type: 'object',
            required: ['autor_nome'],
            properties: {
              autor_nome: { type: 'string', description: 'Nome do autor ou "Autor Desconhecido"', example: 'Machado de Assis' }
            }
          }
        ],
        example: {
          id: 1,
          titulo: 'Dom Casmurro',
          ano: 1899,
          autor_id: 1,
          autor_nome: 'Machado de Assis',
          comentarios: [{ id: 1, autor_nome: 'Leitor', autor_comentario: 'Leitor', texto: 'Clássico indispensável.' }]
        }
      },
      Erro: {
        type: 'object',
        required: ['erro'],
        properties: {
          erro: { type: 'string', description: 'Mensagem legível descrevendo o erro' }
        }
      },
      ErroValidacao: {
        type: 'object',
        required: ['erro', 'detalhes'],
        properties: {
          erro: { type: 'string', example: 'Dados inválidos.' },
          detalhes: {
            type: 'array',
            items: {
              type: 'object',
              required: ['campo', 'mensagem'],
              properties: {
                campo: { type: 'string', example: 'email' },
                mensagem: { type: 'string', example: 'Deve ser um e-mail válido.' }
              }
            }
          }
        }
      }
    },
    responses: {
      Unauthorized: {
        description: 'Não autenticado: token ausente, fora do formato `Bearer <token>`, inválido/adulterado ou expirado.',
        content: {
          'application/json': {
            schema: { $ref: '#/components/schemas/Erro' },
            examples: {
              ausente: { summary: 'Header Authorization ausente', value: { erro: 'Token de autenticação não fornecido.' } },
              formato: { summary: 'Sem o prefixo Bearer', value: { erro: 'Formato inválido. Use: Authorization: Bearer <token>.' } },
              invalido: { summary: 'Assinatura inválida ou token corrompido', value: { erro: 'Token inválido.' } },
              expirado: { summary: 'Token expirado', value: { erro: 'Token expirado. Faça login novamente.' } }
            }
          }
        }
      },
      ForbiddenAdmin: {
        description: 'Proibido: o usuário está autenticado, mas não tem o perfil ADMIN.',
        content: {
          'application/json': {
            schema: { $ref: '#/components/schemas/Erro' },
            example: { erro: 'Acesso proibido: privilégio de ADMIN exigido.' }
          }
        }
      },
      LivroNaoEncontrado: {
        description: 'Nenhum livro encontrado com o `id` informado.',
        content: {
          'application/json': {
            schema: { $ref: '#/components/schemas/Erro' },
            example: { erro: 'Livro não localizado.' }
          }
        }
      },
      ErroInterno: {
        description: 'Erro inesperado no servidor (ex.: falha ao ler o arquivo de dados).',
        content: {
          'application/json': {
            schema: { $ref: '#/components/schemas/Erro' },
            example: { erro: 'Ocorreu um erro interno no servidor.' }
          }
        }
      }
    }
  }
};

const spec = swaggerJsdoc({
  definition,
  apis: [path.join(__dirname, '..', 'routes', '*.js')],
  failOnErrors: true
});

module.exports = spec;
