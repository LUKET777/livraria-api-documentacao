const swaggerUi = require('swagger-ui-express');

/**
 * Configuração da interface Swagger UI.
 * - Carrega a especificação a partir do JSON bruto (/api/docs.json);
 * - persistAuthorization mantém o token após recarregar a página;
 * - o responseInterceptor captura o token de um login bem-sucedido e o aplica
 *   automaticamente no botão "Authorize" (esquema bearerAuth).
 */
const opcoes = {
  customSiteTitle: 'Livraria API — Documentação',
  customCss: '.swagger-ui .topbar { display: none }',
  swaggerOptions: {
    url: '/api/docs.json',
    persistAuthorization: true,
    displayRequestDuration: true,
    tryItOutEnabled: true,
    docExpansion: 'list',
    defaultModelsExpandDepth: 1,
    responseInterceptor: function (res) {
      try {
        if (res && res.ok && /\/auth\/login$/.test(res.url) && res.body && res.body.token && window.ui) {
          window.ui.preauthorizeApiKey('bearerAuth', res.body.token);
          console.log('[Livraria API] Token JWT aplicado automaticamente em Authorize (perfil: ' + res.body.usuario.role + ').');
        }
      } catch (e) { /* não interrompe a resposta exibida */ }
      return res;
    }
  }
};

module.exports = {
  serve: swaggerUi.serveFiles(null, opcoes),
  setup: swaggerUi.setup(null, opcoes)
};
