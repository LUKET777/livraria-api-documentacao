/**
 * Helpers de validação que padronizam os erros conforme o contrato OpenAPI:
 *  - 400 Bad Request          -> campo obrigatório ausente
 *  - 422 Unprocessable Entity -> campo presente, mas com tipo/formato/valor inválido
 * Os erros são lançados como objetos { status, message, detalhes } e tratados no errorMiddleware.
 */

const vazio = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');

function exigirCampos(dados, campos, mensagem) {
  const faltando = campos.filter(c => vazio(dados[c]));
  if (faltando.length) {
    throw {
      status: 400,
      message: mensagem || `Campos obrigatórios ausentes: ${faltando.join(', ')}.`,
      detalhes: faltando.map(campo => ({ campo, mensagem: 'Campo obrigatório.' }))
    };
  }
}

function lancarSeInvalido(detalhes) {
  if (detalhes.length) {
    throw { status: 422, message: 'Dados inválidos.', detalhes };
  }
}

function validarTexto(detalhes, campo, valor, { min = 1, max } = {}) {
  if (typeof valor !== 'string') {
    detalhes.push({ campo, mensagem: 'Deve ser um texto.' });
    return;
  }
  const tamanho = valor.trim().length;
  if (tamanho < min || (max && tamanho > max)) {
    const msg = min > 1 ? `Deve ter entre ${min} e ${max} caracteres.` : `Deve ter no máximo ${max} caracteres.`;
    detalhes.push({ campo, mensagem: msg });
  }
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

module.exports = { vazio, exigirCampos, lancarSeInvalido, validarTexto, EMAIL_REGEX };
