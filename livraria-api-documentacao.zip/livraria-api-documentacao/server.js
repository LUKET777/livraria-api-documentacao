require('dotenv').config({ quiet: true });
const path = require('path');
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/authRoutes');
const livroRoutes = require('./routes/livroRoutes');
const autorRoutes = require('./routes/autorRoutes');
const errorHandler = require('./middlewares/errorMiddleware');
const openapiSpec = require('./docs/openapi');
const swaggerDocs = require('./docs/swaggerUi');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Front-end de teste (index.html) servido em http://localhost:3000
app.use(express.static(path.join(__dirname, 'public')));

// Documentação OpenAPI 3.0
// Especificação bruta em JSON (também disponível no alias /api-docs.json)
app.get(['/api/docs.json', '/api-docs.json'], (req, res) => res.json(openapiSpec));
// Interface interativa (Swagger UI) em /api/docs; /docs redireciona para ela
app.use('/api/docs', swaggerDocs.serve, swaggerDocs.setup);
app.get('/docs', (req, res) => res.redirect(301, '/api/docs'));

// Agrupamento Semântico de Rotas (RESTful /api/v1)
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/livros', livroRoutes);
app.use('/api/v1/autores', autorRoutes);

// Middleware Global de Tratamento de Erros
app.use(errorHandler);

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Livraria API rodando em http://localhost:${PORT}`);
    console.log(`Documentação (Swagger UI): http://localhost:${PORT}/api/docs`);
    console.log(`Especificação OpenAPI (JSON): http://localhost:${PORT}/api/docs.json`);
  });
}

module.exports = app;