# 📚 Livraria API — Documentação OpenAPI 3.0 (Swagger UI)

**Aluno:** Lucas Figueredo  
**Matrícula:** 2410469

API RESTful de Livros e Autores (Node.js + Express, Clean Architecture), evoluída da atividade de segurança (BCrypt + JWT + RBAC) com **contrato formal documentado em OpenAPI 3.0** e interface interativa **Swagger UI**.

## 📖 Documentação da API

| Recurso | URL |
|---|---|
| Swagger UI (interativo) | **http://localhost:3000/api/docs** (`/docs` redireciona para cá) |
| Especificação OpenAPI bruta (JSON) | **http://localhost:3000/api/docs.json** (alias: `/api-docs.json`) |

**Como testar as rotas protegidas pelo navegador:**
1. Abra `/api/docs` → **Autenticação → POST /auth/login** → *Try it out* → escolha o exemplo `admin` ou `leitor` → *Execute*.
2. O token JWT retornado é aplicado **automaticamente** no botão **Authorize** 🔒 (também é possível colar o token manualmente em *Authorize → bearerAuth*).
3. Execute as rotas de comentários, autores e livros. Para trocar de perfil, faça login com o outro usuário (o token é substituído) ou use *Authorize → Logout*.

**O que está documentado em cada rota:** sumário e descrição das regras, schema do corpo com campos `required`, tipos, limites e exemplos realistas, respostas de sucesso (200/201) com schema, e respostas de erro (400, 422, 401, 403, 404, 409, 500) com exemplos. O esquema de segurança é `http` / `bearer` / `JWT` (`bearerAuth`), aplicado apenas às rotas protegidas.

**Implementação:** anotações `@openapi` (JSDoc) nos arquivos de `routes/`, lidas pelo `swagger-jsdoc`; definição base, schemas e respostas reutilizáveis em `docs/openapi.js`; interface servida por `swagger-ui-express` (`docs/swaggerUi.js`). A especificação é validada automaticamente nos testes com `@apidevtools/swagger-parser`.

## 🛡️ Segurança (atividade anterior)

| Requisito | Implementação |
|---|---|
| Armazenamento seguro de credenciais | **BCrypt** (`bcryptjs`) com salt aleatório por senha e *work factor* configurável (padrão 10) |
| Autenticação stateless | **JWT** HS256 assinado no login, validado no header `Authorization: Bearer <token>` |
| Controle de acesso (RBAC) | Middlewares `autenticarToken` (401) e `exigirRole('ADMIN')` (403) |

## ▶️ Como executar

```bash
npm install
cp .env.example .env        # depois troque o JWT_SECRET por um valor aleatório
npm start                   # http://localhost:3000
npm test                    # testes de segurança + documentação/validação
```

O front-end de teste fica em `public/index.html` e é servido em **http://localhost:3000**. A documentação fica em **http://localhost:3000/api/docs**.

> Se você já tinha um `database.txt` da versão anterior, ele é corrigido automaticamente na inicialização (os hashes fictícios dos usuários-semente são trocados pelos reais).

## 🔑 Credenciais de teste

| Perfil | E-mail | Senha |
|---|---|---|
| ADMIN | admin@livraria.com | admin123 |
| USER (Leitor) | leitor@gmail.com | leitor123 |

## 📋 Matriz de permissões e contratos

| Método | Rota | Acesso | Sucesso | Falhas documentadas |
|---|---|---|---|---|
| GET | `/api/v1/livros` | Público | 200 | 500 |
| GET | `/api/v1/livros/{id}` | Público | 200 | 404, 500 |
| GET | `/api/v1/autores` | Público | 200 | 500 |
| POST | `/api/v1/auth/register` | Público | 201 | 400, 422, 409, 500 |
| POST | `/api/v1/auth/login` | Público | 200 | 400, 422, 401, 500 |
| POST | `/api/v1/livros/{id}/comentarios` | USER ou ADMIN | 201 | 400, 422, 401, 404, 500 |
| POST | `/api/v1/autores` | Exclusivo ADMIN | 201 | 400, 422, 401, 403, 500 |
| POST | `/api/v1/livros` | Exclusivo ADMIN | 201 | 400, 422, 401, 403, 500 |

**Convenção 400 x 422:** `400` quando o corpo está ausente, o JSON está malformado ou falta um campo obrigatório; `422` quando os campos foram enviados, mas com tipo, formato ou valor inválido (e-mail inválido, senha com menos de 6 caracteres, `ano` não inteiro ou futuro, `autor_id` de autor inexistente, comentário com mais de 1000 caracteres). Ambos retornam `{ "erro": "...", "detalhes": [{ "campo", "mensagem" }] }`.

## 🛡️ Decisões de segurança

- **Senha nunca em texto puro:** `bcrypt.hash(senha, 10)` no cadastro e `bcrypt.compare` no login; o hash nunca é retornado pela API.
- **Sem escalonamento de privilégio:** o cadastro público sempre cria perfil `USER`, mesmo que o corpo envie `"role": "ADMIN"`.
- **Mensagem de erro genérica no login** ("Credenciais inválidas") e comparação BCrypt mesmo quando o e-mail não existe, para não revelar quais e-mails estão cadastrados.
- **JWT validado com algoritmo fixo** (`algorithms: ['HS256']`), bloqueando tokens `alg: none` e tokens assinados com outro segredo; expiração padrão de 1h.
- **Segredo fora do código:** `JWT_SECRET` vem do `.env` (ignorado pelo Git) e a API se recusa a subir se ele faltar ou tiver menos de 32 caracteres.
- **Autor do comentário vem do token**, não do corpo da requisição.
- **401 x 403:** 401 = sem token / token inválido ou expirado; 403 = autenticado, mas sem o perfil exigido.

## 🧪 Exemplos (curl)

```bash
# Login (ADMIN)
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@livraria.com","senha":"admin123"}'

# Cadastrar autor com o token retornado
curl -X POST http://localhost:3000/api/v1/autores \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <TOKEN>" \
  -d '{"nome":"Clarice Lispector","nacionalidade":"Brasileira"}'
```

## 📁 Arquivos alterados/criados nesta etapa

- `docs/openapi.js` — definição OpenAPI 3.0 (info, servidor, tags, `bearerAuth`, schemas e respostas reutilizáveis)
- `docs/swaggerUi.js` — configuração do Swagger UI (persistência do token e Authorize automático após login)
- `routes/*.js` — anotações `@openapi` de cada endpoint
- `server.js` — rotas `/api/docs`, `/api/docs.json`, `/api-docs.json` e redirecionamento de `/docs`
- `utils/validacao.js` + `services/*.js` — validação alinhada ao contrato (400 x 422)
- `middlewares/errorMiddleware.js` — formato de erro padronizado, JSON malformado → 400 e 500 sem expor detalhes internos
- `public/index.html` — link para a documentação e envio de `ano`/`autor_id` como números
- `tests/documentacao.test.js` — valida a especificação, a matriz de status codes e a validação 400/422
- `.env.example` e `.gitignore`
