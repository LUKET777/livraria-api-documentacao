const repository = require('../repositories/LivrariaRepository');
const { exigirCampos, lancarSeInvalido, validarTexto, vazio } = require('../utils/validacao');

class AutorService {
  listarTodos() {
    return repository.listarAutores();
  }

  criar(dados) {
    const { nome, nacionalidade } = dados || {};
    exigirCampos({ nome }, ['nome'], "O nome do autor é obrigatório.");

    const detalhes = [];
    validarTexto(detalhes, 'nome', nome, { min: 2, max: 120 });
    if (!vazio(nacionalidade)) validarTexto(detalhes, 'nacionalidade', nacionalidade, { max: 60 });
    lancarSeInvalido(detalhes);

    return repository.salvarAutor({
      nome: nome.trim(),
      nacionalidade: vazio(nacionalidade) ? "Não informada" : nacionalidade.trim()
    });
  }
}

module.exports = new AutorService();