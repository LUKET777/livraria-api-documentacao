const repository = require('../repositories/LivrariaRepository');
const { exigirCampos, lancarSeInvalido, validarTexto, vazio } = require('../utils/validacao');

class LivroService {
  listarTodos() {
    const livros = repository.listarLivros();
    const autores = repository.listarAutores();

    return livros.map(livro => {
      const autor = autores.find(a => a.id === livro.autor_id);
      return {
        ...livro,
        autor_nome: autor ? autor.nome : "Autor Desconhecido",
        comentarios: this._formatarComentarios(livro.comentarios)
      };
    });
  }

  // Expõe também "autor_comentario", campo lido pelo front-end (index.html)
  _formatarComentarios(comentarios = []) {
    return comentarios.map(c => ({ ...c, autor_comentario: c.autor_nome }));
  }

  buscarPorId(id) {
    const livro = repository.buscarLivroPorId(id);
    if (!livro) {
      throw { status: 404, message: "Livro não localizado." };
    }

    const autor = repository.buscarAutorPorId(livro.autor_id);
    return {
      ...livro,
      autor_nome: autor ? autor.nome : "Autor Desconhecido",
      comentarios: this._formatarComentarios(livro.comentarios)
    };
  }

  criar(dados) {
    const { titulo, ano, autor_id } = dados || {};
    exigirCampos({ titulo, autor_id }, ['titulo', 'autor_id']);

    const anoAtual = new Date().getFullYear();
    const detalhes = [];
    validarTexto(detalhes, 'titulo', titulo, { max: 200 });
    if (!vazio(ano) && (!Number.isInteger(ano) || ano < 1 || ano > anoAtual)) {
      detalhes.push({ campo: 'ano', mensagem: 'Deve ser um número inteiro entre 1 e o ano atual.' });
    }
    if (!Number.isInteger(autor_id) || autor_id < 1) {
      detalhes.push({ campo: 'autor_id', mensagem: 'Deve ser um número inteiro positivo.' });
    } else if (!repository.buscarAutorPorId(autor_id)) {
      detalhes.push({ campo: 'autor_id', mensagem: 'O autor informado não existe.' });
    }
    lancarSeInvalido(detalhes);

    return repository.salvarLivro({
      titulo: titulo.trim(),
      ano: vazio(ano) ? anoAtual : ano,
      autor_id
    });
  }

  adicionarComentario(livroId, { texto, usuario }) {
    exigirCampos({ texto }, ['texto'], "O texto do comentário não pode estar vazio.");
    const detalhes = [];
    validarTexto(detalhes, 'texto', texto, { max: 1000 });
    lancarSeInvalido(detalhes);

    this.buscarPorId(livroId);

    // Autor do comentário vem do JWT validado, nunca do corpo da requisição
    const comentario = repository.adicionarComentario(livroId, {
      usuario_id: usuario.id,
      autor_nome: usuario.nome,
      texto: String(texto).trim()
    });
    return { ...comentario, autor_comentario: comentario.autor_nome };
  }
}

module.exports = new LivroService();