const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const repository = require('../repositories/LivrariaRepository');
const { JWT_SECRET, JWT_EXPIRES_IN, JWT_ALGORITHM, BCRYPT_SALT_ROUNDS } = require('../config/auth');
const { exigirCampos, lancarSeInvalido, validarTexto, EMAIL_REGEX } = require('../utils/validacao');

// Hash fictício usado quando o e-mail não existe, para que a resposta leve
// o mesmo tempo de um login real (evita enumeração de usuários por timing).
const HASH_FICTICIO = bcrypt.hashSync('senha-ficticia-para-timing', BCRYPT_SALT_ROUNDS);

class AuthService {
  async registrar(dados) {
    const { nome, email, senha } = dados || {};
    exigirCampos({ nome, email, senha }, ['nome', 'email', 'senha']);

    const detalhes = [];
    validarTexto(detalhes, 'nome', nome, { min: 2, max: 100 });
    if (typeof email !== 'string' || email.trim().length > 254 || !EMAIL_REGEX.test(email.trim())) {
      detalhes.push({ campo: 'email', mensagem: 'Deve ser um e-mail válido.' });
    }
    // BCrypt considera no máximo 72 bytes da senha
    if (typeof senha !== 'string' || senha.length < 6 || Buffer.byteLength(senha) > 72) {
      detalhes.push({ campo: 'senha', mensagem: 'Deve ter entre 6 e 72 caracteres.' });
    }
    lancarSeInvalido(detalhes);

    const emailNormalizado = email.trim().toLowerCase();

    const usuarioExistente = repository.buscarUsuarioPorEmail(emailNormalizado);
    if (usuarioExistente) {
      throw { status: 409, message: "E-mail já cadastrado no sistema." };
    }

    // BCrypt: gera salt aleatório e aplica o work factor (custo 2^rounds)
    const senha_hash = await bcrypt.hash(String(senha), BCRYPT_SALT_ROUNDS);

    // Segurança: o cadastro público SEMPRE cria perfil USER.
    // Qualquer "role" enviada no corpo é ignorada (impede escalonamento de privilégio).
    const novoUsuario = repository.salvarUsuario({
      nome: String(nome).trim(),
      email: emailNormalizado,
      senha_hash,
      role: "USER"
    });

    const { senha_hash: _, ...usuarioRetorno } = novoUsuario;
    return usuarioRetorno;
  }

  async login(dados) {
    const { email, senha } = dados || {};
    exigirCampos({ email, senha }, ['email', 'senha'], "E-mail e senha são obrigatórios.");

    const detalhes = [];
    if (typeof email !== 'string') detalhes.push({ campo: 'email', mensagem: 'Deve ser um texto.' });
    if (typeof senha !== 'string') detalhes.push({ campo: 'senha', mensagem: 'Deve ser um texto.' });
    lancarSeInvalido(detalhes);

    const usuario = repository.buscarUsuarioPorEmail(String(email).trim().toLowerCase());

    // Compara sempre (mesmo sem usuário) para manter tempo de resposta constante
    const senhaConfere = await bcrypt.compare(String(senha), usuario ? usuario.senha_hash : HASH_FICTICIO);

    if (!usuario || !senhaConfere) {
      // Mensagem genérica: não revela se o erro foi no e-mail ou na senha
      throw { status: 401, message: "Credenciais inválidas." };
    }

    const token = jwt.sign(
      { nome: usuario.nome, role: usuario.role },
      JWT_SECRET,
      { subject: String(usuario.id), expiresIn: JWT_EXPIRES_IN, algorithm: JWT_ALGORITHM }
    );

    return {
      usuario: { id: usuario.id, nome: usuario.nome, role: usuario.role },
      token
    };
  }
}

module.exports = new AuthService();
