/**
 * Middleware global de erros. Produz sempre o formato documentado na OpenAPI:
 *   { erro: string }  ou  { erro: string, detalhes: [{ campo, mensagem }] }
 */
function errorHandler(err, req, res, next) {
  // JSON malformado no corpo (lançado pelo express.json)
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({
      erro: "JSON malformado no corpo da requisição.",
      detalhes: [{ campo: 'body', mensagem: 'O corpo deve ser um JSON válido.' }]
    });
  }

  const statusCode = Number(err && err.status) || 500;

  // Erros 500 não expõem detalhes internos ao cliente
  if (statusCode >= 500) {
    console.error(err);
    return res.status(500).json({ erro: "Ocorreu um erro interno no servidor." });
  }

  const corpo = { erro: err.message || "Requisição inválida." };
  if (Array.isArray(err.detalhes)) corpo.detalhes = err.detalhes;
  return res.status(statusCode).json(corpo);
}

module.exports = errorHandler;
